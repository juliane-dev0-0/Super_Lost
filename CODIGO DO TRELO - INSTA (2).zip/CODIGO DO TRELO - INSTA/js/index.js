let taskMax = 0;
let columnId = 0; //variavel global que é usada para obter o valor da coluna ao clicar add task

const taskPerColumn = []
const taskNum = [];
const arrayDeTaskNum = [ [], [], [] ];

class TaskSpecs {
    titulo;
    descricao;
};

function abrirModalDelete(id_card) {
    const modal = new bootstrap.Modal("#modalDelete");
    const deleteButton = document.getElementById('btn_modal_delete');
    deleteButton.onclick = function() {
        const teste = document.getElementById(id_card);
        document.getElementById(id_card).remove();
        deletarLocalStorage(id_card);
        modal.hide();
    };
    modal.toggle();

}

// function deletarLocalStorage(id_card) {
//     const taskMax = parseInt(id_card.split('_')[1]); // Extract taskMax from id_card
//     localStorage.removeItem(`task${taskMax}`);
//     localStorage.removeItem(`descricaoTask${taskMax}`);

//     taskNum[taskMax]=undefined;
//     console.log(localStorage);
// }

function deletarLocalStorage(id_card) {
    console.log(id_card);
 
    const taskIndex = id_card.split("_")[1];
    console.log(taskIndex);
    // Remova a tarefa do array aninhado
    if (arrayDeTaskNum[columnIndex] && arrayDeTaskNum[columnIndex][taskIndex]) {
        arrayDeTaskNum[columnIndex].splice(taskIndex, 1);
    }

    // Atualize o localStorage
    localStorage.removeItem(`task${columnIndex}_${taskIndex}`);
    localStorage.removeItem(`descricaoTask${columnIndex}_${taskIndex}`);
}


function add_task() {
    const titulo = document.getElementById('input_1').value;
    const descricao = document.getElementById('area_descricao').value;
    if (!titulo) {
        return false;
    } else {
        salvarEssesDados(titulo, descricao);
        limpacampos();
    }
}

function limpacampos() {
    document.getElementById('input_1').value = '';
    document.getElementById('area_descricao').value = '';
    document.getElementById('btn_delete').style.display = 'none';
}

function carregarDados(title, descricao, taskMax) {
    document.getElementById('input_1').value = title;
    document.getElementById('area_descricao').value = descricao;
    document.getElementById('btn_delete').style.display = '';
    document.getElementById('btn_delete').setAttribute('onclick', `abrirModalDelete('card_${taskMax}_${columnId.match(/\d+/g)}')`);
}

function armazenarId(id){
    const idColuna = document.getElementById(id).previousElementSibling.id;
    columnId=idColuna;
}

function salvarEssesDados(title, descricao) {
    var novaTarefa = document.createElement('div');
    novaTarefa.innerHTML = `
        <div class="card text-bg-success mb-3 mx-auto p-2" style="max-width: 15rem; cursor: pointer;" 
         onclick="carregarDados('${title}', `+'`'+`${descricao}`+'`'+`, ${taskMax})"
         data-bs-toggle="modal" data-bs-target="#staticBackdrop" id="card_${taskMax}_${columnId.match(/\d+/g)}" >
            <div class="card-header d-flex justify-content-between">
                <h5 class="card-title text-center" id="title_card_view_${taskMax}">${title}</h5>
            </div>
            <div class="card-body">
                <p class="card-text" id="description_card_view_${taskMax}">${descricao ? descricao : "Sem Descrição"}</p>
            </div>
        </div>
    `;

    //SaveTask()
    const paputs = arrayDeTaskNum[columnId.match(/\d+/g)]
    const structDados = new TaskSpecs();
    structDados.titulo = document.getElementById('input_1').value;
    structDados.descricao = document.getElementById('area_descricao').value;
    //taskNum.push(structDados);
    paputs.push(structDados)

    for (let i = 0; i < arrayDeTaskNum.length; i++) {
        const coluna = arrayDeTaskNum[i];
        console.log(coluna); 
    
        for (let j = 0; j < coluna.length; j++) {
            const tarefa = coluna[j];
            const tituloJSON = tarefa.titulo;
            const descricaoJSON = tarefa.descricao;
            localStorage.setItem(`task${j}_column${i}`, JSON.stringify(tituloJSON));
            localStorage.setItem(`descricaoTask${j}_column${i}`, JSON.stringify(descricaoJSON));
            
            console.log(tarefa)
        }
    }

    //saveTask - fim
    var novaColuna = document.getElementById(`columnId${columnId.match(/\d+/g)}`);
    novaColuna.appendChild(novaTarefa);
    taskMax++;
}

function deletarItem(event) {
    event.target.parentElement.parentElement.remove();
   
}
 




function mudaFundo(cor) {
    document.body.style.backgroundColor = cor;
   
    
    localStorage.setItem('colorBackground', cor);
}





function background() {
    let div = document.getElementById('color_menu');
    div.style.display = div.style.display === 'block' ? 'none' : 'block';
}

document.addEventListener("DOMContentLoaded", function salvarFundo(){
    const corSalva = localStorage.getItem('colorBackground');
     if (corSalva) {
         document.body.style.backgroundColor=corSalva;
    }
});

